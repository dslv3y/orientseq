Tool to orient seq
